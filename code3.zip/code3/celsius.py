inp = input('Enter Celsius Temperature:')
cel = float(inp)
fahr = (cel * 9.0) / 5.0 + 32.0
print(fahr)
